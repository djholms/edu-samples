require 'spec_helper'

describe 'rspec_example' do
  it { is_expected.to compile }
end
